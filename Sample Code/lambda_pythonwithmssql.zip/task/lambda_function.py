import sys
import pyodbc
import json
import boto3
import base64
import os
from botocore.exceptions import ClientError

print(pyodbc.drivers())

def lambda_handler(event, context):
    
    customerName = event['Name']
    secret = ''
    secret_name = 'dbconnection'
    region_name = 'us-east-1'
    session = boto3.session.Session()
    client = session.client(service_name='secretsmanager',region_name=region_name)
    get_secret_value_response = client.get_secret_value(SecretId=secret_name)
    #print('response is : ')
    print(get_secret_value_response)
    if 'SecretString' in get_secret_value_response:
        secret = get_secret_value_response['SecretString']
    
    conn =pyodbc.connect(secret)
    crs = conn.cursor()
    strQuery = "select Name, CompanyName, Country, phone from [dbo].[Customer] where Name = '" + customerName + "'"
    rows = crs.execute(strQuery).fetchall()
    #print(rows)
    items = []
    for row in rows:
        items.append({'Name': row[0], 'companyname': row[1], 'country': row[2], 'phone': row[3] })
    crs.close()
    conn.close()
    print(json.dumps({'details': items}))
    return {
        'statusCode': 200,
        'body': json.dumps({'details': items})
    }
   
    
