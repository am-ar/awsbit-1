
def lambda_handler(event, context):
    import pyodbc
    import json
    import boto3
    import base64
    from botocore.exceptions import ClientError
    secret_name = "crmdatanase"
    region_name = "us-east-1"
    secret = ""
    sqlinput = event['Name']
    strsqloutput = []
    print(sqlinput)
    # Create a Secrets Manager client
    #{
    #"first_name": "John",
    #"last_name": "Smith"
    #}
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name
        )
    try:
            get_secret_value_response = client.get_secret_value(
                SecretId=secret_name
            )
    except ClientError as e:
                raise e
    else:
            if 'SecretString' in get_secret_value_response:
                secret = get_secret_value_response['SecretString']
                print("secret")
                print(secret)

                conn =pyodbc.connect(secret)
                crs = conn.cursor()
                strQuery = "select Name, CompanyName, EmailAddress, Country, phone, customeraddress, customerinformation, imageurl from [dbo].[Customer] where Name = '" + sqlinput + "'"
                rows = crs.execute(strQuery).fetchall()
                #print(rows)
                items = []
                for row in rows:
                    items.append({'Name': row[0], 'companyname': row[1], 'EmailAddress': row[2], 'country': row[3], 'phone': row[4], 'customeraddress': row[5], 'customerinformation': row[6], 'imageurl': row[7] })
                crs.close()
                conn.close()
                print(json.dumps({'details': items}))
                return {
                    'statusCode': 200,
                    'body': json.dumps({'details': items})
                }







                with pyodbc.connect(secret) as conn:
                   with conn.cursor() as cursor:
                        strQuery = "Select top 1 * from customer where name = '" + sqlinput + "'"
                        print(strQuery)
                        cursor.execute(strQuery)
                        print('cursor.execute')
                        rows = cursor.fetchone()
                        print('cursor.fetchone')
                        print(rows)
                        while rows:
                            #print(str(rows[0]))
                            #rows = cursor.fetchone()
                            for row in rows:
                                sqloutputrow = (row[0], row[1], row[2], row[3], row[4], row[5], row[6])
                                print(sqloutputrow)
                                strsqloutput.append(sqloutputrow)
                        jsonsqloutput = json.dumps(strsqloutput)
                                


