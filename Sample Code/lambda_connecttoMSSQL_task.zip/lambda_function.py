
def lambda_handler(event, context):
    import pyodbc
    import json
    #import boto3
    import base64
    #from botocore.exceptions import ClientError
    #secret_name = "crmdatanase"
    region_name = "us-east-1"
    #secret = ""
    sqlinput = event['Name']
    #sqlinput = 'kumar'
    strsqloutput = []
    print(sqlinput)
    # Create a Secrets Manager client
    #{
    #"first_name": "John",
    #"last_name": "Smith"
    #}
    #my_Customerdict = dict()
    jsonsqloutput = ""
    my_Customerdict = {"customerid":[],"name":[],"CompanyName":[],"EmailAddress":[],"country":[],"phone":[],"customeraddress":[],"customerinformation":[],"imageurl":[]};


    with pyodbc.connect("DRIVER={ODBC Driver 13 for SQL Server}; SERVER=oneengineer.database.windows.net;PORT=1433;DATABASE=oneengineer;UID=oneengineer;PWD=Exensys1@3") as conn:
       with conn.cursor() as cursor:
            strQuery = "Select top 1 [customer id], [name], CompanyName, EmailAddress, country, phone, customeraddress, customerinformation, imageurl from customer where name = '" + sqlinput + "'"
            print(strQuery)
            cursor.execute(strQuery)
            print('cursor.execute')
            rows = cursor.fetchone()
            #print('cursor.fetchone')
            my_Customerdict["customerid"].append(rows[0])
            my_Customerdict["name"].append(rows[1])
            my_Customerdict["CompanyName"].append(rows[2])
            my_Customerdict["EmailAddress"].append(rows[3])
            my_Customerdict["country"].append(rows[4])
            my_Customerdict["phone"].append(rows[5])
            my_Customerdict["customeraddress"].append(rows[6])
            my_Customerdict["customerinformation"].append(rows[7])
            my_Customerdict["imageurl"].append(rows[8])	
            #print(my_Customerdict)
            #while rows:
                #print(str(rows[0]))
                #rows = cursor.fetchone()
            #for row in rows:
                    #sqloutputrow = (row[0], row[1], row[2], row[3], row[4], row[5], row[6])
            #        print(row)
                    #strsqloutput.append(sqloutputrow)
            jsonsqloutput = json.dumps(my_Customerdict)
            print(jsonsqloutput)
    return jsonsqloutput
                                


